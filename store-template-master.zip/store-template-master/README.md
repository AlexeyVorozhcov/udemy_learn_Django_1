# store-template

Template code "Django for Beginners"

https://pavlov-school.ru
